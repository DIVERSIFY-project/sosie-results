/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.collections4;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import junit.framework.TestCase;
import junit.framework.TestSuite;
// It was easier to use a separate class to do all the reflection stuff
// for making the TestSuite instances.  Having permanent state around makes
// it easier to handle the recursion.
public class BulkTestSuiteMaker {

    /** The class that defines simple and bulk tests methods. */
    private final Class<? extends BulkTest> startingClass;

    /** List of ignored simple test names. */
    private List<String> ignored;

    /** The TestSuite we're currently populating.  Can change over time. */
    private TestSuite result;

    /**
     * The prefix for simple test methods.  Used to check if a test is in
     * the ignored list.
     */
    private String prefix;

    /**
     * Constructor.
     *
     * @param startingClass  the starting class
     */
    public BulkTestSuiteMaker(final Class<? extends BulkTest> startingClass) {
        this.startingClass = startingClass;
    }

    /**
     * Makes a hierarchical TestSuite based on the starting class.
     *
     * @return  the hierarchical TestSuite for startingClass
     */
    public TestSuite make() {
         this.result = new TestSuite();
         this.prefix = getBaseName(startingClass);
         result.setName(prefix);

         final BulkTest bulk = makeFirstTestCase(startingClass);
         ignored = new ArrayList<String>();
         final String[] s = bulk.ignoredTests();
         if (s != null) {
             ignored.addAll(Arrays.asList(s));
         }
         make(bulk);
         return result;
    }

    /**
     * Appends all the simple tests and bulk tests defined by the given
     * instance's class to the current TestSuite.
     *
     * @param bulk  An instance of the class that defines simple and bulk
     *    tests for us to append
     */
    void make(final BulkTest bulk) {
        final Class<? extends BulkTest> c = bulk.getClass();
        final Method[] all = c.getMethods();
        for (final Method element : all) {
            if (isTest(element)) {
                addTest(bulk, element);
            }
            if (isBulk(element)) {
                addBulk(bulk, element);
            }
        }
    }

    /**
     * Adds the simple test defined by the given method to the TestSuite.
     *
     * @param bulk  The instance of the class that defined the method
     *   (I know it's weird.  But the point is, we can clone the instance
     *   and not have to worry about constructors.)
     * @param m  The simple test method
     */
    void addTest(final BulkTest bulk, final Method m) {
        final BulkTest bulk2 = (BulkTest)bulk.clone();
        bulk2.setName(m.getName());
        bulk2.verboseName = prefix + "." + m.getName();
        if (ignored.contains(bulk2.verboseName)) {
            return;
        }
        result.addTest(bulk2);
    }

    /**
     * Adds a whole new suite of tests that are defined by the result of
     * the given bulk test method.  In other words, the given bulk test
     * method is invoked, and the resulting BulkTest instance is examined
     * for yet more simple and bulk tests.
     *
     * @param bulk  The instance of the class that defined the method
     * @param m  The bulk test method
     */
    void addBulk(final BulkTest bulk, final Method m) {
        final String verboseName = prefix + "." + m.getName();
        if (ignored.contains(verboseName)) {
            return;
        }

        BulkTest bulk2;
        try {
            bulk2 = (BulkTest)m.invoke(bulk, (Object[]) null);
            if (bulk2 == null) {
                return;
            }
        } catch (final InvocationTargetException ex) {
            ex.getTargetException().printStackTrace();
            throw new Error(); // FIXME;
        } catch (final IllegalAccessException ex) {
            ex.printStackTrace();
            throw new Error(); // FIXME;
        }

        // Save current state on the stack.
        final String oldPrefix = prefix;
        final TestSuite oldResult = result;

        prefix = prefix + "." + m.getName();
        result = new TestSuite();
        result.setName(m.getName());

        make(bulk2);

        oldResult.addTest(result);

        // Restore the old state
        prefix = oldPrefix;
        result = oldResult;
    }

    /**
     * Returns the base name of the given class.
     *
     * @param c  the class
     * @return the name of that class, minus any package names
     */
    private static String getBaseName(final Class<?> c) {
        String name = c.getName();
        final int p = name.lastIndexOf('.');
        if (p > 0) {
            name = name.substring(p + 1);
        }
        return name;
    }


    // These three methods are used to create a valid BulkTest instance
    // from a class.

    private static <T> Constructor<T> getTestCaseConstructor(final Class<T> c) {
        try {
            return c.getConstructor(new Class[] { String.class });
        } catch (final NoSuchMethodException e) {
            throw new IllegalArgumentException(c + " must provide a (String) constructor");
        }
    }

    private static <T extends BulkTest> BulkTest makeTestCase(final Class<T> c, final Method m) {
        final Constructor<T> con = getTestCaseConstructor(c);
        try {
            return con.newInstance(m.getName());
        } catch (final InvocationTargetException e) {
            e.printStackTrace();
            throw new RuntimeException(); // FIXME;
        } catch (final IllegalAccessException e) {
            throw new Error(); // should never occur
        } catch (final InstantiationException e) {
            throw new RuntimeException(); // FIXME;
        }
    }

    private static <T extends BulkTest> BulkTest makeFirstTestCase(final Class<T> c) {
        final Method[] all = c.getMethods();
        for (final Method element : all) {
            if (isTest(element)) {
                return makeTestCase(c, element);
            }
        }
        throw new IllegalArgumentException(c.getName() + " must provide at least one test method.");
    }

    /**
     * Returns true if the given method is a simple test method.
     */
    private static boolean isTest(final Method m) {
        if (!m.getName().startsWith("test")) {
            return false;
        }
        if (m.getReturnType() != Void.TYPE) {
            return false;
        }
        if (m.getParameterTypes().length != 0) {
            return false;
        }
        final int mods = m.getModifiers();
        if (Modifier.isStatic(mods)) {
            return false;
        }
        if (Modifier.isAbstract(mods)) {
            return false;
        }
        return true;
    }

    /**
     * Returns true if the given method is a bulk test method.
     */
    private static boolean isBulk(final Method m) {
        if (!m.getName().startsWith("bulkTest")) {
            return false;
        }
        if (m.getReturnType() != BulkTest.class) {
            return false;
        }
        if (m.getParameterTypes().length != 0) {
            return false;
        }
        final int mods = m.getModifiers();
        if (Modifier.isStatic(mods)) {
            return false;
        }
        if (Modifier.isAbstract(mods)) {
            return false;
        }
        return true;
    }

}
