/**
 * Native language support (i18n).
 */
package org.eclipse.jgit.nls;
