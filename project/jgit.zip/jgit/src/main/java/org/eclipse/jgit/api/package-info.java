/**
 * High-level API commands (the porcelain of JGit).
 */
package org.eclipse.jgit.api;
