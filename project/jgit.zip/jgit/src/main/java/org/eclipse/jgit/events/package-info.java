/**
 * Events and listener interfaces.
 */
package org.eclipse.jgit.events;
