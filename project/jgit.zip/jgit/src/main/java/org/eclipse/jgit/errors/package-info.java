/**
 * Exceptions thrown by lower-level JGit APIs.
 */
package org.eclipse.jgit.errors;
