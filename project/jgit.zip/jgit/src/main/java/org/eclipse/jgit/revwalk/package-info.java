/**
 * Walking revision graphs (commit history).
 */
package org.eclipse.jgit.revwalk;
