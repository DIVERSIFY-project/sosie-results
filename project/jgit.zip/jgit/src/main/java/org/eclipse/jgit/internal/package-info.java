/**
 * Internal classes.
 */
package org.eclipse.jgit.internal;
