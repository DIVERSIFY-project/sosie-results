/**
 * Git submodule support.
 */
package org.eclipse.jgit.submodule;
