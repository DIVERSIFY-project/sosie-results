/**
 * Comparing file contents by computing diffs.
 */
package org.eclipse.jgit.diff;
