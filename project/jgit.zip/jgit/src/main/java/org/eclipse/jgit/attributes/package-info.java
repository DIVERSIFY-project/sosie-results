/**
 * Support for reading .gitattributes.
 */
package org.eclipse.jgit.attributes;
