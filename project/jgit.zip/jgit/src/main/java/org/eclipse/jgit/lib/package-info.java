/**
 * Core API for repository, config, refs, object database.
 */
package org.eclipse.jgit.lib;
