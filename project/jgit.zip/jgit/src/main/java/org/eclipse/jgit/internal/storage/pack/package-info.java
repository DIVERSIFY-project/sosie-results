/**
 * Reading/writing Git pack files.
 */
package org.eclipse.jgit.internal.storage.pack;
