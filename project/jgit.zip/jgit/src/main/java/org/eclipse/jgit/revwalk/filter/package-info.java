/**
 * Filters for use in revision walking.
 */
package org.eclipse.jgit.revwalk.filter;
