/**
 * Building/rendering revision graphs.
 */
package org.eclipse.jgit.revplot;
