This maven module can be used for various IDEs like NetBeans or Eclipse to
make GraphHopper offline routing working on Android. For offline
maps the mapsforge project is used. For more information see the 
[android docs](https://github.com/graphhopper/graphhopper/blob/master/docs/android/index.md).

![simple routing](http://karussell.files.wordpress.com/2012/09/graphhopper-android.png)
