Add GraphHopper Maps to your Browser
----

## Firefox

1. go to http://graphhopper.com/maps
2. Then right click into the search bar and select 'add GraphHopper Maps' (here 'GraphHopper Maps' hinzufügen)
3. Finally select 'GraphHopper Maps' and type your locations. Put 'p:' before your every location.

![firefox](http://karussell.files.wordpress.com/2013/08/firefox.png)

## Chrome

1. Open your settings in chrome and go to 'search' to add a new search engine. Use the URL `http://graphhopper.com/maps/?q=%s`
2. Finally search via GraphHopper Maps: type 'gh ' and then put 'p:' before your locations.
![chrome](http://karussell.files.wordpress.com/2013/08/chrome.png)